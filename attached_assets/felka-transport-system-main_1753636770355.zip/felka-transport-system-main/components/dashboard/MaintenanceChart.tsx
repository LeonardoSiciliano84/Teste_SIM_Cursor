'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'

const monthlyData = [
  { month: 'Jan', preventiva: 12, corretiva: 8, custo: 45000 },
  { month: 'Fev', preventiva: 15, corretiva: 6, custo: 38000 },
  { month: 'Mar', preventiva: 18, corretiva: 9, custo: 52000 },
  { month: 'Abr', preventiva: 14, corretiva: 7, custo: 41000 },
  { month: 'Mai', preventiva: 16, corretiva: 5, custo: 35000 },
  { month: 'Jun', preventiva: 20, corretiva: 8, custo: 48000 }
]

const typeData = [
  { name: 'Preventiva', value: 65, color: '#22c55e' },
  { name: 'Corretiva', value: 35, color: '#ef4444' }
]

export function MaintenanceChart() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Análise de Manutenção</CardTitle>
        <CardDescription>
          Comparativo mensal de manutenções preventivas vs corretivas
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Bar Chart */}
          <div>
            <h4 className="font-semibold mb-3 text-sm">Manutenções por Mês</h4>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="preventiva" fill="#22c55e" name="Preventiva" />
                <Bar dataKey="corretiva" fill="#ef4444" name="Corretiva" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Pie Chart */}
          <div>
            <h4 className="font-semibold mb-3 text-sm">Distribuição por Tipo</h4>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={typeData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {typeData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex justify-center space-x-4 mt-2">
              {typeData.map((item, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: item.color }}
                  />
                  <span className="text-xs text-muted-foreground">
                    {item.name} ({item.value}%)
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-3 gap-4 mt-6 pt-6 border-t">
          <div className="text-center">
            <p className="text-2xl font-bold text-success-600">95</p>
            <p className="text-xs text-muted-foreground">Total Preventivas</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-error-600">43</p>
            <p className="text-xs text-muted-foreground">Total Corretivas</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-primary-600">R$ 259k</p>
            <p className="text-xs text-muted-foreground">Custo Total</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}