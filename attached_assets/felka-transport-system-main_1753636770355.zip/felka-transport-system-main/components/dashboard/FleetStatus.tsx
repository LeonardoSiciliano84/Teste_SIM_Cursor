import { Truck, Wrench, CheckCircle, AlertTriangle } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'

const fleetData = {
  total: 127,
  active: 119,
  maintenance: 5,
  inactive: 3,
  availability: 94.2
}

const vehiclesByType = [
  { type: 'Caminhões', count: 85, percentage: 67 },
  { type: 'Vans', count: 25, percentage: 20 },
  { type: 'Carretas', count: 12, percentage: 9 },
  { type: 'Outros', count: 5, percentage: 4 }
]

const maintenanceStatus = [
  { vehicle: 'ABC-1234', type: 'Preventiva', progress: 75, eta: '2h' },
  { vehicle: 'DEF-5678', type: 'Corretiva', progress: 45, eta: '4h' },
  { vehicle: 'GHI-9012', type: 'Preventiva', progress: 90, eta: '30min' },
  { vehicle: 'JKL-3456', type: 'Corretiva', progress: 20, eta: '6h' },
  { vehicle: 'MNO-7890', type: 'Preventiva', progress: 60, eta: '3h' }
]

export function FleetStatus() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Truck className="w-5 h-5" />
          Status da Frota
        </CardTitle>
        <CardDescription>
          Visão geral da disponibilidade e manutenção dos veículos
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Fleet Overview */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center p-4 bg-success-50 rounded-lg border border-success-200">
            <CheckCircle className="w-8 h-8 text-success-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-success-800">{fleetData.active}</p>
            <p className="text-sm text-success-600">Ativos</p>
          </div>
          
          <div className="text-center p-4 bg-warning-50 rounded-lg border border-warning-200">
            <Wrench className="w-8 h-8 text-warning-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-warning-800">{fleetData.maintenance}</p>
            <p className="text-sm text-warning-600">Manutenção</p>
          </div>
          
          <div className="text-center p-4 bg-error-50 rounded-lg border border-error-200">
            <AlertTriangle className="w-8 h-8 text-error-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-error-800">{fleetData.inactive}</p>
            <p className="text-sm text-error-600">Inativos</p>
          </div>
          
          <div className="text-center p-4 bg-primary-50 rounded-lg border border-primary-200">
            <div className="text-2xl font-bold text-primary-800">{fleetData.availability}%</div>
            <p className="text-sm text-primary-600">Disponibilidade</p>
          </div>
        </div>

        {/* Vehicle Types */}
        <div>
          <h4 className="font-semibold mb-3">Composição da Frota</h4>
          <div className="space-y-3">
            {vehiclesByType.map((item, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 rounded-full bg-primary" style={{
                    backgroundColor: `hsl(${index * 60}, 70%, 50%)`
                  }} />
                  <span className="text-sm font-medium">{item.type}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-muted-foreground">{item.count}</span>
                  <Badge variant="secondary" className="text-xs">
                    {item.percentage}%
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Maintenance in Progress */}
        <div>
          <h4 className="font-semibold mb-3">Manutenções em Andamento</h4>
          <div className="space-y-3">
            {maintenanceStatus.map((item, index) => (
              <div key={index} className="p-3 bg-muted/50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <span className="font-medium text-sm">{item.vehicle}</span>
                    <Badge variant={item.type === 'Preventiva' ? 'default' : 'destructive'} className="text-xs">
                      {item.type}
                    </Badge>
                  </div>
                  <span className="text-xs text-muted-foreground">ETA: {item.eta}</span>
                </div>
                <Progress value={item.progress} className="h-2" />
                <p className="text-xs text-muted-foreground mt-1">{item.progress}% concluído</p>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}