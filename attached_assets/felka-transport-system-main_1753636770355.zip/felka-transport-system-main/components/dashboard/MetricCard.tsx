import { DivideIcon as LucideIcon } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'

interface MetricCardProps {
  title: string
  value: string
  change: string
  trend: 'up' | 'down' | 'neutral'
  icon: LucideIcon
  description?: string
}

export function MetricCard({ 
  title, 
  value, 
  change, 
  trend, 
  icon: Icon, 
  description 
}: MetricCardProps) {
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className={cn(
              "w-12 h-12 rounded-lg flex items-center justify-center",
              trend === 'up' && "bg-success-100 text-success-600",
              trend === 'down' && "bg-error-100 text-error-600",
              trend === 'neutral' && "bg-primary-100 text-primary-600"
            )}>
              <Icon className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">{title}</p>
              <p className="text-2xl font-bold text-foreground">{value}</p>
            </div>
          </div>
          <Badge 
            variant={trend === 'up' ? 'default' : trend === 'down' ? 'destructive' : 'secondary'}
            className={cn(
              trend === 'up' && "bg-success-100 text-success-800 hover:bg-success-100",
              trend === 'down' && "bg-error-100 text-error-800 hover:bg-error-100"
            )}
          >
            {change}
          </Badge>
        </div>
        {description && (
          <p className="text-xs text-muted-foreground mt-2">{description}</p>
        )}
      </CardContent>
    </Card>
  )
}