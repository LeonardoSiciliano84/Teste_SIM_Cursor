import { Clock, User, Truck, Wrench, Package } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

const activities = [
  {
    id: 1,
    type: 'maintenance',
    title: 'O.S. #1234 finalizada',
    description: 'Troca de óleo - Caminhão ABC-1234',
    time: '2 min atrás',
    icon: Wrench,
    status: 'completed'
  },
  {
    id: 2,
    type: 'checklist',
    title: 'Checklist de saída',
    description: 'João Silva - Veículo DEF-5678',
    time: '15 min atrás',
    icon: Truck,
    status: 'active'
  },
  {
    id: 3,
    type: 'stock',
    title: 'Estoque baixo',
    description: 'Filtro de óleo - 5 unidades restantes',
    time: '1h atrás',
    icon: Package,
    status: 'warning'
  },
  {
    id: 4,
    type: 'employee',
    title: 'Novo colaborador',
    description: 'Maria Santos cadastrada no sistema',
    time: '2h atrás',
    icon: User,
    status: 'info'
  },
  {
    id: 5,
    type: 'maintenance',
    title: 'Preventiva agendada',
    description: 'Caminhão GHI-9012 - Revisão 10.000km',
    time: '3h atrás',
    icon: Clock,
    status: 'scheduled'
  }
]

export function RecentActivities() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Atividades Recentes</CardTitle>
        <CardDescription>
          Últimas movimentações do sistema
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {activities.map((activity) => (
          <div key={activity.id} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
              activity.status === 'completed' ? 'bg-success-100 text-success-600' :
              activity.status === 'warning' ? 'bg-warning-100 text-warning-600' :
              activity.status === 'active' ? 'bg-primary-100 text-primary-600' :
              'bg-muted text-muted-foreground'
            }`}>
              <activity.icon className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-foreground truncate">
                  {activity.title}
                </p>
                <Badge 
                  variant={
                    activity.status === 'completed' ? 'default' :
                    activity.status === 'warning' ? 'destructive' :
                    'secondary'
                  }
                  className="ml-2 text-xs"
                >
                  {activity.status === 'completed' ? 'Concluído' :
                   activity.status === 'warning' ? 'Atenção' :
                   activity.status === 'active' ? 'Ativo' :
                   'Info'}
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {activity.description}
              </p>
              <p className="text-xs text-muted-foreground mt-1 flex items-center">
                <Clock className="w-3 h-3 mr-1" />
                {activity.time}
              </p>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}