'use client'

import Link from 'next/link'
import { 
  Home, 
  Truck, 
  CheckSquare, 
  AlertTriangle, 
  Phone,
  User,
  ArrowLeft
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'

interface MobileLayoutProps {
  children: React.ReactNode
}

export function MobileLayout({ children }: MobileLayoutProps) {
  return (
    <div className="min-h-screen bg-background">
      {/* Mobile Header */}
      <div className="sticky top-0 z-50 bg-card border-b px-4 py-3">
        <div className="flex items-center justify-between">
          <Link href="/">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
          </Link>
          
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Truck className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-bold">FELKA Mobile</span>
          </div>

          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-success-500 rounded-full" />
            <span className="text-xs text-muted-foreground">Online</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="p-4 pb-20">
        {children}
      </main>

      {/* Mobile Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-card border-t px-4 py-2 z-50">
        <div className="grid grid-cols-5 gap-1">
          <Link href="/mobile" className="flex flex-col items-center justify-center py-2 px-1">
            <Home className="w-5 h-5 text-primary" />
            <span className="text-xs text-primary font-medium">Início</span>
          </Link>
          
          <button className="flex flex-col items-center justify-center py-2 px-1">
            <CheckSquare className="w-5 h-5 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Checklist</span>
          </button>
          
          <button className="flex flex-col items-center justify-center py-2 px-1">
            <Truck className="w-5 h-5 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Veículo</span>
          </button>
          
          <button className="flex flex-col items-center justify-center py-2 px-1 relative">
            <AlertTriangle className="w-5 h-5 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Alertas</span>
            <Badge className="absolute -top-1 -right-1 w-4 h-4 p-0 flex items-center justify-center text-xs">
              2
            </Badge>
          </button>
          
          <button className="flex flex-col items-center justify-center py-2 px-1">
            <User className="w-5 h-5 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Perfil</span>
          </button>
        </div>
      </div>
    </div>
  )
}