import { Suspense } from 'react'
import { 
  BarChart3, 
  Users, 
  Truck, 
  Wrench, 
  Package, 
  Shield,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Clock,
  DollarSign,
  Activity
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { DashboardLayout } from '@/components/layout/DashboardLayout'
import { MetricCard } from '@/components/dashboard/MetricCard'
import { RecentActivities } from '@/components/dashboard/RecentActivities'
import { FleetStatus } from '@/components/dashboard/FleetStatus'
import { MaintenanceChart } from '@/components/dashboard/MaintenanceChart'

export default function DashboardPage() {
  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Dashboard Executivo</h1>
            <p className="text-muted-foreground">Visão geral das operações da transportadora</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm">
              <BarChart3 className="w-4 h-4 mr-2" />
              Relatórios
            </Button>
            <Button size="sm">
              <Activity className="w-4 h-4 mr-2" />
              Tempo Real
            </Button>
          </div>
        </div>

        {/* KPIs Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard
            title="Frota Ativa"
            value="127"
            change="+2.5%"
            trend="up"
            icon={Truck}
            description="Veículos operacionais"
          />
          <MetricCard
            title="Disponibilidade"
            value="94.2%"
            change="+1.2%"
            trend="up"
            icon={CheckCircle}
            description="Frota disponível"
          />
          <MetricCard
            title="Custo/KM"
            value="R$ 2.34"
            change="-0.8%"
            trend="down"
            icon={DollarSign}
            description="Média mensal"
          />
          <MetricCard
            title="Manutenções"
            value="23"
            change="+5"
            trend="up"
            icon={Wrench}
            description="Em andamento"
          />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Fleet Status */}
          <div className="lg:col-span-2">
            <Suspense fallback={<div className="h-96 bg-muted animate-pulse rounded-lg" />}>
              <FleetStatus />
            </Suspense>
          </div>

          {/* Recent Activities */}
          <div>
            <Suspense fallback={<div className="h-96 bg-muted animate-pulse rounded-lg" />}>
              <RecentActivities />
            </Suspense>
          </div>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Suspense fallback={<div className="h-80 bg-muted animate-pulse rounded-lg" />}>
            <MaintenanceChart />
          </Suspense>

          {/* Alerts Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-warning-500" />
                Alertas Críticos
              </CardTitle>
              <CardDescription>
                Itens que requerem atenção imediata
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-error-50 rounded-lg border border-error-200">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-error-500 rounded-full" />
                  <div>
                    <p className="font-medium text-error-800">Documentos Vencidos</p>
                    <p className="text-sm text-error-600">5 veículos com IPVA vencido</p>
                  </div>
                </div>
                <Badge variant="destructive">Crítico</Badge>
              </div>

              <div className="flex items-center justify-between p-3 bg-warning-50 rounded-lg border border-warning-200">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-warning-500 rounded-full" />
                  <div>
                    <p className="font-medium text-warning-800">Manutenção Atrasada</p>
                    <p className="text-sm text-warning-600">3 preventivas em atraso</p>
                  </div>
                </div>
                <Badge className="bg-warning-100 text-warning-800">Atenção</Badge>
              </div>

              <div className="flex items-center justify-between p-3 bg-primary-50 rounded-lg border border-primary-200">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-primary-500 rounded-full" />
                  <div>
                    <p className="font-medium text-primary-800">Estoque Baixo</p>
                    <p className="text-sm text-primary-600">12 itens abaixo do mínimo</p>
                  </div>
                </div>
                <Badge variant="secondary">Info</Badge>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Ações Rápidas</CardTitle>
            <CardDescription>
              Acesso direto às funcionalidades mais utilizadas
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {[
                { icon: Users, label: 'Novo Colaborador', href: '/rh/colaboradores/novo' },
                { icon: Truck, label: 'Cadastrar Veículo', href: '/frota/veiculos/novo' },
                { icon: Wrench, label: 'Nova O.S.', href: '/manutencao/ordens/nova' },
                { icon: Package, label: 'Entrada Estoque', href: '/almoxarifado/entrada' },
                { icon: Shield, label: 'Controle Portaria', href: '/portaria' },
                { icon: BarChart3, label: 'Relatórios', href: '/relatorios' }
              ].map((action, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="h-20 flex-col gap-2 hover:bg-primary/5"
                >
                  <action.icon className="w-6 h-6" />
                  <span className="text-xs text-center">{action.label}</span>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}