import Link from 'next/link'
import { 
  Truck, 
  Users, 
  Wrench, 
  Package, 
  Shield, 
  BarChart3,
  ArrowRight,
  CheckCircle,
  Clock,
  TrendingUp,
  Star,
  Zap,
  Target
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted/20">
      {/* Header */}
      <header className="border-b bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Truck className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">FELKA</h1>
                <p className="text-sm text-muted-foreground">Sistema Integrado</p>
              </div>
            </div>
            <Link href="/auth/login">
              <Button>
                Entrar no Sistema
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="animate-fade-in">
            <Badge variant="secondary" className="mb-4">
              <Star className="w-3 h-3 mr-1" />
              Plataforma Líder em Gestão de Transportadoras
            </Badge>
            <h2 className="text-4xl md:text-6xl font-bold text-foreground mb-6">
              Gestão Completa para
              <span className="text-primary block">Transportadoras</span>
            </h2>
            <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto leading-relaxed">
              Plataforma integrada que centraliza RH, manutenção de frota, almoxarifado, 
              controle de portaria e dashboards gerenciais em uma solução única e moderna.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/dashboard">
                <Button size="lg" className="text-lg px-8 py-3">
                  <BarChart3 className="w-5 h-5 mr-2" />
                  Ver Dashboard Demo
                </Button>
              </Link>
              <Link href="/mobile">
                <Button variant="outline" size="lg" className="text-lg px-8 py-3">
                  <Truck className="w-5 h-5 mr-2" />
                  Interface Motorista
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-card/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center border-0 shadow-lg">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-success-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="w-8 h-8 text-success-600" />
                </div>
                <div className="text-3xl font-bold text-foreground mb-2">40%</div>
                <p className="text-muted-foreground">Redução em custos administrativos</p>
              </CardContent>
            </Card>
            <Card className="text-center border-0 shadow-lg">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-8 h-8 text-primary-600" />
                </div>
                <div className="text-3xl font-bold text-foreground mb-2">95%</div>
                <p className="text-muted-foreground">Adesão ao checklist digital</p>
              </CardContent>
            </Card>
            <Card className="text-center border-0 shadow-lg">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-accent-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-8 h-8 text-accent-600" />
                </div>
                <div className="text-3xl font-bold text-foreground mb-2">30%</div>
                <p className="text-muted-foreground">Redução no tempo de manutenção</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Modules Section */}
      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge variant="outline" className="mb-4">
              <Zap className="w-3 h-3 mr-1" />
              Módulos Integrados
            </Badge>
            <h3 className="text-3xl font-bold text-foreground mb-4">Solução Completa</h3>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Cada módulo foi desenvolvido para trabalhar em perfeita sinergia, 
              garantindo eficiência operacional e controle total.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: Users,
                title: "RH & Departamento Pessoal",
                description: "Gestão completa de colaboradores, documentos e ocorrências com controle de vencimentos.",
                color: "bg-blue-500",
                features: ["Cadastro completo", "Controle de documentos", "Gerador de ocorrências"]
              },
              {
                icon: Truck,
                title: "Gestão de Frota",
                description: "Controle total da frota com dados técnicos, financeiros e histórico de manutenções.",
                color: "bg-green-500",
                features: ["Cadastro de veículos", "Controle financeiro", "Integração FIPE"]
              },
              {
                icon: Wrench,
                title: "Manutenção",
                description: "Fluxo Kanban para ordens de serviço com controle de preventivas e prazos.",
                color: "bg-orange-500",
                features: ["Kanban interativo", "Preventivas automáticas", "Controle de custos"]
              },
              {
                icon: Package,
                title: "Almoxarifado",
                description: "Gestão de estoque, materiais e armazéns de clientes com controle de lotes.",
                color: "bg-purple-500",
                features: ["Controle de estoque", "Acautelamentos", "Armazéns de clientes"]
              },
              {
                icon: Shield,
                title: "Portaria",
                description: "Controle de acesso para veículos e visitantes com interface otimizada para tablet.",
                color: "bg-red-500",
                features: ["Controle de veículos", "Gestão de visitantes", "Interface tablet"]
              },
              {
                icon: BarChart3,
                title: "Dashboards Gerenciais",
                description: "Indicadores e métricas em tempo real para tomada de decisão estratégica.",
                color: "bg-indigo-500",
                features: ["KPIs em tempo real", "Relatórios executivos", "Análises financeiras"]
              }
            ].map((module, index) => (
              <Card key={index} className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
                <CardHeader>
                  <div className={`w-12 h-12 ${module.color} rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-200`}>
                    <module.icon className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-xl">{module.title}</CardTitle>
                  <CardDescription className="leading-relaxed">{module.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {module.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center text-sm text-muted-foreground">
                        <CheckCircle className="w-4 h-4 text-success-500 mr-2 flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="container mx-auto text-center px-4 sm:px-6 lg:px-8">
          <Badge variant="secondary" className="mb-6">
            <Target className="w-3 h-3 mr-1" />
            Transformação Digital
          </Badge>
          <h3 className="text-3xl font-bold mb-6">
            Pronto para Transformar sua Operação?
          </h3>
          <p className="text-xl text-primary-foreground/80 mb-8 max-w-2xl mx-auto">
            Digitalize sua transportadora com a plataforma mais completa do mercado.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/dashboard">
              <Button variant="secondary" size="lg" className="text-lg px-8 py-3">
                <BarChart3 className="w-5 h-5 mr-2" />
                Explorar Sistema
              </Button>
            </Link>
            <Link href="/mobile">
              <Button variant="outline" size="lg" className="text-lg px-8 py-3 border-primary-foreground/20 text-primary-foreground hover:bg-primary-foreground/10">
                <Truck className="w-5 h-5 mr-2" />
                Ver Interface Mobile
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t py-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-3 mb-4 md:mb-0">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Truck className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold text-foreground">FELKA</span>
            </div>
            <p className="text-muted-foreground text-sm">
              © 2024 FELKA. Sistema Integrado de Manutenção para Transportadoras.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}