import { Suspense } from 'react'
import { 
  Users, 
  UserPlus, 
  FileText, 
  AlertTriangle, 
  Calendar,
  TrendingUp,
  Clock,
  CheckCircle
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { DashboardLayout } from '@/components/layout/DashboardLayout'
import { MetricCard } from '@/components/dashboard/MetricCard'

export default function RHPage() {
  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Recursos Humanos</h1>
            <p className="text-muted-foreground">Gestão de colaboradores e departamento pessoal</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm">
              <FileText className="w-4 h-4 mr-2" />
              Relatórios
            </Button>
            <Button size="sm">
              <UserPlus className="w-4 h-4 mr-2" />
              Novo Colaborador
            </Button>
          </div>
        </div>

        {/* KPIs Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard
            title="Colaboradores Ativos"
            value="248"
            change="+3.2%"
            trend="up"
            icon={Users}
            description="Total de funcionários"
          />
          <MetricCard
            title="Documentos Vencidos"
            value="12"
            change="+2"
            trend="up"
            icon={AlertTriangle}
            description="Requer atenção"
          />
          <MetricCard
            title="Admissões (Mês)"
            value="8"
            change="+1"
            trend="up"
            icon={TrendingUp}
            description="Novas contratações"
          />
          <MetricCard
            title="Ocorrências Abertas"
            value="3"
            change="-2"
            trend="down"
            icon={FileText}
            description="Em andamento"
          />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Recent Employees */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Colaboradores Recentes
              </CardTitle>
              <CardDescription>
                Últimas admissões e atualizações
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  {
                    name: 'Maria Santos',
                    role: 'Motorista',
                    admission: '15/01/2024',
                    status: 'Ativo',
                    documents: 'Completo'
                  },
                  {
                    name: 'João Silva',
                    role: 'Mecânico',
                    admission: '10/01/2024',
                    status: 'Ativo',
                    documents: 'Pendente'
                  },
                  {
                    name: 'Ana Costa',
                    role: 'Auxiliar Administrativo',
                    admission: '08/01/2024',
                    status: 'Ativo',
                    documents: 'Completo'
                  },
                  {
                    name: 'Carlos Oliveira',
                    role: 'Motorista',
                    admission: '05/01/2024',
                    status: 'Documentação',
                    documents: 'Pendente'
                  }
                ].map((employee, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center">
                        <Users className="w-5 h-5 text-primary-600" />
                      </div>
                      <div>
                        <p className="font-medium">{employee.name}</p>
                        <p className="text-sm text-muted-foreground">{employee.role}</p>
                        <p className="text-xs text-muted-foreground">Admissão: {employee.admission}</p>
                      </div>
                    </div>
                    <div className="text-right space-y-1">
                      <Badge 
                        variant={employee.status === 'Ativo' ? 'default' : 'secondary'}
                      >
                        {employee.status}
                      </Badge>
                      <div className="flex items-center text-xs">
                        {employee.documents === 'Completo' ? (
                          <CheckCircle className="w-3 h-3 text-success-500 mr-1" />
                        ) : (
                          <Clock className="w-3 h-3 text-warning-500 mr-1" />
                        )}
                        <span className={employee.documents === 'Completo' ? 'text-success-600' : 'text-warning-600'}>
                          {employee.documents}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Document Alerts */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-warning-500" />
                Alertas de Documentos
              </CardTitle>
              <CardDescription>
                Documentos próximos ao vencimento
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                {
                  employee: 'Pedro Santos',
                  document: 'CNH',
                  expires: '25/01/2024',
                  days: 3,
                  severity: 'critical'
                },
                {
                  employee: 'Maria Silva',
                  document: 'ASO',
                  expires: '02/02/2024',
                  days: 11,
                  severity: 'warning'
                },
                {
                  employee: 'João Costa',
                  document: 'Curso MOPP',
                  expires: '15/02/2024',
                  days: 24,
                  severity: 'info'
                }
              ].map((alert, index) => (
                <div 
                  key={index} 
                  className={`p-3 rounded-lg border ${
                    alert.severity === 'critical' ? 'bg-error-50 border-error-200' :
                    alert.severity === 'warning' ? 'bg-warning-50 border-warning-200' :
                    'bg-primary-50 border-primary-200'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <p className="font-medium text-sm">{alert.employee}</p>
                    <Badge 
                      variant={
                        alert.severity === 'critical' ? 'destructive' :
                        alert.severity === 'warning' ? 'secondary' :
                        'default'
                      }
                      className="text-xs"
                    >
                      {alert.days} dias
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">{alert.document}</p>
                  <p className="text-xs text-muted-foreground">Vence: {alert.expires}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Department Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Motoristas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary-600">156</div>
              <p className="text-xs text-muted-foreground">62.9% do total</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Mecânicos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-secondary-600">28</div>
              <p className="text-xs text-muted-foreground">11.3% do total</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Administrativo</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-accent-600">42</div>
              <p className="text-xs text-muted-foreground">16.9% do total</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Outros</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-muted-foreground">22</div>
              <p className="text-xs text-muted-foreground">8.9% do total</p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Ações Rápidas - RH</CardTitle>
            <CardDescription>
              Acesso direto às funcionalidades mais utilizadas
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { icon: UserPlus, label: 'Admitir Colaborador', href: '/rh/colaboradores/novo' },
                { icon: FileText, label: 'Gerar Ocorrência', href: '/rh/ocorrencias/nova' },
                { icon: Calendar, label: 'Controle de Ponto', href: '/rh/ponto' },
                { icon: AlertTriangle, label: 'Documentos Vencidos', href: '/rh/documentos/vencidos' }
              ].map((action, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="h-20 flex-col gap-2 hover:bg-primary/5"
                >
                  <action.icon className="w-6 h-6" />
                  <span className="text-xs text-center">{action.label}</span>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}