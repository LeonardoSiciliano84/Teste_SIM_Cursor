import { Suspense } from 'react'
import { 
  Truck, 
  CheckSquare, 
  AlertTriangle, 
  Phone, 
  MapPin,
  Clock,
  Fuel,
  Settings
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { MobileLayout } from '@/components/layout/MobileLayout'

export default function MobilePage() {
  return (
    <MobileLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground">Interface do Motorista</h1>
          <p className="text-muted-foreground">Bem-vindo, João Silva</p>
          <Badge variant="secondary" className="mt-2">
            <Clock className="w-3 h-3 mr-1" />
            Turno: 06:00 - 18:00
          </Badge>
        </div>

        {/* Vehicle Selection */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Truck className="w-5 h-5" />
              Selecionar Veículo
            </CardTitle>
            <CardDescription>
              Escolha o veículo para iniciar o checklist
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {[
              { placa: 'ABC-1234', modelo: 'Volvo FH 540', km: '245.678', status: 'Disponível' },
              { placa: 'DEF-5678', modelo: 'Scania R450', km: '189.432', status: 'Disponível' },
              { placa: 'GHI-9012', modelo: 'Mercedes Actros', km: '156.789', status: 'Manutenção' }
            ].map((vehicle, index) => (
              <div 
                key={index} 
                className={`p-4 border rounded-lg ${
                  vehicle.status === 'Disponível' 
                    ? 'border-success-200 bg-success-50 hover:bg-success-100 cursor-pointer' 
                    : 'border-muted bg-muted/50 cursor-not-allowed'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold">{vehicle.placa}</p>
                    <p className="text-sm text-muted-foreground">{vehicle.modelo}</p>
                    <p className="text-xs text-muted-foreground">KM: {vehicle.km}</p>
                  </div>
                  <Badge 
                    variant={vehicle.status === 'Disponível' ? 'default' : 'destructive'}
                  >
                    {vehicle.status}
                  </Badge>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-4">
          <Button className="h-20 flex-col gap-2" size="lg">
            <CheckSquare className="w-6 h-6" />
            <span className="text-sm">Iniciar Checklist</span>
          </Button>
          
          <Button variant="outline" className="h-20 flex-col gap-2" size="lg">
            <AlertTriangle className="w-6 h-6" />
            <span className="text-sm">Reportar Problema</span>
          </Button>
        </div>

        {/* Current Trip Info */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="w-5 h-5" />
              Viagem Atual
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Origem:</span>
                <span className="font-medium">São Paulo - SP</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Destino:</span>
                <span className="font-medium">Rio de Janeiro - RJ</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Distância:</span>
                <span className="font-medium">429 km</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Previsão:</span>
                <span className="font-medium">6h 30min</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Vehicle Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Fuel className="w-5 h-5" />
              Status do Veículo
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-3 bg-success-50 rounded-lg">
                <p className="text-lg font-bold text-success-600">85%</p>
                <p className="text-xs text-success-600">Combustível</p>
              </div>
              <div className="text-center p-3 bg-primary-50 rounded-lg">
                <p className="text-lg font-bold text-primary-600">OK</p>
                <p className="text-xs text-primary-600">Pneus</p>
              </div>
              <div className="text-center p-3 bg-success-50 rounded-lg">
                <p className="text-lg font-bold text-success-600">Normal</p>
                <p className="text-xs text-success-600">Temperatura</p>
              </div>
              <div className="text-center p-3 bg-warning-50 rounded-lg">
                <p className="text-lg font-bold text-warning-600">Baixo</p>
                <p className="text-xs text-warning-600">Óleo</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Emergency Contact */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Phone className="w-5 h-5" />
              Contato de Emergência
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Button variant="destructive" className="w-full" size="lg">
              <Phone className="w-5 h-5 mr-2" />
              Ligar para Central: (11) 9999-9999
            </Button>
          </CardContent>
        </Card>
      </div>
    </MobileLayout>
  )
}